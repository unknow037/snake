#include "LORA.h"
#include "usart.h"
#include <string.h>
#include <stdbool.h>

/* 调试输出：通过串口1打印（不影响串口2的LoRa通信） */
static void LORA_Debug(const char *str)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), 50);
}

/* 调试输出 hex_buf（固定2字节，无'\0'结尾） */
static void LORA_Debug_Hex(uint8_t *buf)
{
    HAL_UART_Transmit(&huart1, buf, 2, 10);
}

/* --- 内部辅助函数 --- */

/**
 * @brief 动态修改 huart2 的波特率
 * @note 在透传模式和配置模式间切换时调用
 */
static void LORA_UART_ReInit(uint32_t baudrate) {
    HAL_UART_DeInit(&huart2);
    huart2.Init.BaudRate = baudrate;
    // 保持其他参数 (8N1, 假设)
    if (HAL_UART_Init(&huart2) != HAL_OK) {
        Error_Handler();
    }
    // 重新启动 DMA 接收
    USART2_DMA_Receive(RxBuffer2, USART2_RX_BUFFER_SIZE);
}

/* --- GPIO 引脚操作宏 --- */
// M0=PB14, M1=PB15, AUX=PA6, RST=PA7
#define M0_PORT     GPIOB
#define M0_PIN      GPIO_PIN_14
#define M1_PORT     GPIOB
#define M1_PIN      GPIO_PIN_15
#define AUX_PORT    GPIOA
#define AUX_PIN     GPIO_PIN_6
#define RST_PORT    GPIOA
#define RST_PIN     GPIO_PIN_7

#define M0_H()      HAL_GPIO_WritePin(M0_PORT, M0_PIN, GPIO_PIN_SET)
#define M0_L()      HAL_GPIO_WritePin(M0_PORT, M0_PIN, GPIO_PIN_RESET)
#define M1_H()      HAL_GPIO_WritePin(M1_PORT, M1_PIN, GPIO_PIN_SET)
#define M1_L()      HAL_GPIO_WritePin(M1_PORT, M1_PIN, GPIO_PIN_RESET)
#define RST_H()     HAL_GPIO_WritePin(RST_PORT, RST_PIN, GPIO_PIN_SET)
#define RST_L()     HAL_GPIO_WritePin(RST_PORT, RST_PIN, GPIO_PIN_RESET)
#define AUX_READ()  HAL_GPIO_ReadPin(AUX_PORT, AUX_PIN)

/**
 * @brief 等待 AUX 引脚变为高电平 (模块空闲)
 * @param timeout: 最大等待时间 (ms)
 * @return true: AUX 变高
 * @return false: 超时
 */
static bool LORA_WaitForAUX(uint32_t timeout) {
    uint32_t start = HAL_GetTick();
    while (AUX_READ() == GPIO_PIN_RESET) {
        if (HAL_GetTick() - start > timeout) {
            return false; // 超时
        }
    }
    // 手册建议 AUX 上升沿 2ms 后再操作
    HAL_Delay(2);
    return true;
}

/* --- 公共函数实现 --- */

void LORA_Init(void) {
    // 确保引脚已由 CubeMX 配置为 GPIO_Output (M0, M1, RST) 和 GPIO_Input (AUX)
    LORA_Reset();
    LORA_SetMode(MODE_NORMAL_0);
    // 确保 MCU 的 UART 波特率与模块的透传波特率一致
    // 注意：USART2已经在usart.c中初始化为9600波特率，不需要再次初始化
    // 但需要启动DMA接收
    USART2_DMA_Receive(RxBuffer2, 200);
}

void LORA_Reset(void) {
    RST_L();
    HAL_Delay(5); // 保持低电平复位
    RST_H();
    HAL_Delay(10); // 等待模块启动
    LORA_WaitForAUX(500); // 等待模块自检完成, AUX 变高
}

bool LORA_SetMode(LORA_Mode mode) {
    // 切换模式前必须等待 AUX 变高
    if (!LORA_WaitForAUX(1000)) {
        return false; // AUX 繁忙, 切换失败
    }

    switch (mode) {
        case MODE_NORMAL_0: // 模式0: M1=0, M0=0
            M1_L();
            M0_L();
            break;
        case MODE_WOR_1: // 模式1: M1=0, M0=1
            M1_L();
            M0_H();
            break;
        case MODE_CONFIG_2: // 模式2: M1=1, M0=0
            M1_H();
            M0_L();
            break;
        case MODE_SLEEP_3: // 模式3: M1=1, M0=1
            M1_H();
            M0_H();
            break;
    }

    HAL_Delay(10); // 确保电平稳定
    // 等待模式切换完成 (AUX 会拉低再拉高, 或保持高)
    return LORA_WaitForAUX(500);
}

bool LORA_Transmit_Broadcast(uint8_t* pData, uint16_t Size) {
    // 1. 确保在模式0
    if (!LORA_SetMode(MODE_NORMAL_0)) {
        return false; // 切换模式失败
    }

    // 2. 等待模块空闲 (AUX 高)
    if (!LORA_WaitForAUX(1000)) {
        return false; // 模块繁忙, 可能上一包数据还没发完
    }

    // 3. 使用DMA发送数据
    USART2_DMA_Transmit(pData, Size);
    // DMA发送是异步的，函数返回表示已发送

    // (DMA 发送是异步的, AUX 会在数据包写入 RF 芯片期间拉低)
    return true;
}


/**
 * @brief (内部) 模式2下发送指令并获取响应
 */
static bool LORA_SendCmd_GetResponse(uint8_t* cmd, uint16_t cmd_len, uint8_t* response, uint16_t response_len) {
    // 1. 切换到配置模式
    if (!LORA_SetMode(MODE_CONFIG_2)) {
        return false;
    }

    // 2. 切换 MCU UART 到 9600bps
 //   LORA_UART_ReInit(LORA_CONFIG_BAUD_RATE);

    // 3. 发送指令 (使用阻塞模式, 因为配置时序要求严格)
    // 停止 DMA 接收, 防止干扰
    HAL_UART_AbortReceive(&huart2);

    if (HAL_UART_Transmit(&huart2, cmd, cmd_len, 100) != HAL_OK) {
        goto error_exit;
    }

    // 4. 接收响应
    if (HAL_UART_Receive(&huart2, response, response_len, 500) != HAL_OK) {
        goto error_exit; // 接收超时或失败
    }

    // 5. 恢复到透传模式 (并恢复波特率)
    LORA_SetMode(MODE_NORMAL_0);

    // 6. 重新启动DMA接收 (关键!)
    USART2_DMA_Receive(RxBuffer2, 200);

    return true;

error_exit:
    // 失败也要恢复模式和波特率
    LORA_SetMode(MODE_NORMAL_0);

    // 恢复DMA接收
    USART2_DMA_Receive(RxBuffer2, 200);

    return false;
}

// 辅助函数：将字节转换为十六进制ASCII字符
static void byte_to_hex(uint8_t byte, uint8_t* hex_str) {
    const uint8_t hex_table[] = "0123456789ABCDEF";
    hex_str[0] = hex_table[byte >> 4];
    hex_str[1] = hex_table[byte & 0x0F];
}

bool LORA_WriteReg(uint8_t startAddr, uint8_t len, uint8_t* pData) {
    uint8_t cmd[256];
    uint8_t response[256];
    uint8_t hex_buf[3]; // 用于存储"XX "格式

    if (len > 252) return false; // 防止缓冲区溢出 (3 + 252)

    cmd[0] = 0xC0; // 写寄存器 (掉电保存)
    cmd[1] = startAddr;
    cmd[2] = len;
    memcpy(&cmd[3], pData, len);

    uint16_t cmd_len = 3 + len;
    uint16_t expected_response_len = cmd_len; // 响应格式 C1...

    // 打印发送的命令（通过UART5）
    LORA_Debug("[LORA] Write REG 0x");
    byte_to_hex(startAddr, hex_buf);
    hex_buf[2] = 0; // 字符串结束符
    LORA_Debug_Hex(hex_buf);
    LORA_Debug(": ");

    hex_buf[2] = ' '; // 添加空格分隔符
    for(uint16_t i = 0; i < cmd_len; i++) {
        byte_to_hex(cmd[i], hex_buf);
        LORA_Debug_Hex(hex_buf);
    }
    LORA_Debug("\r\n");

    if (LORA_SendCmd_GetResponse(cmd, cmd_len, response, expected_response_len)) {
        // 打印接收到的响应（通过UART5）
        LORA_Debug("[LORA] Response: ");
        for(uint16_t i = 0; i < expected_response_len; i++) {
            byte_to_hex(response[i], hex_buf);
            LORA_Debug_Hex(hex_buf);
        }
        LORA_Debug("\r\n");

        // 校验响应
        if (response[0] == 0xC1 && response[1] == startAddr && response[2] == len) {
            if (memcmp(&response[3], pData, len) == 0) {
                LORA_Debug("[LORA] Write SUCCESS!\r\n");
                return true; // 写入成功且回读一致
            }
        }
        LORA_Debug("[LORA] Write FAILED - Response mismatch!\r\n");
    } else {
        LORA_Debug("[LORA] Write FAILED - No response!\r\n");
    }
    return false; // 失败
}

bool LORA_ReadReg(uint8_t startAddr, uint8_t len, uint8_t* pBuffer) {
    uint8_t cmd[3];
    uint8_t response[256];
    uint8_t hex_buf[3]; // 用于存储"XX "格式

    if (len > 253) return false; // 防止缓冲区溢出 (3 + 253)

    cmd[0] = 0xC1; // 读寄存器
    cmd[1] = startAddr;
    cmd[2] = len;

    uint16_t cmd_len = 3;
    uint16_t expected_response_len = 3 + len; // 响应格式 C1 + addr + len + params

    // 打印发送的命令（通过UART5）
    LORA_Debug("[LORA] Read REG 0x");
    byte_to_hex(startAddr, hex_buf);
    hex_buf[2] = 0; // 字符串结束符
    LORA_Debug_Hex(hex_buf);
    LORA_Debug(": ");

    hex_buf[2] = ' '; // 添加空格分隔符
    for(uint16_t i = 0; i < cmd_len; i++) {
        byte_to_hex(cmd[i], hex_buf);
        LORA_Debug_Hex(hex_buf);
    }
    LORA_Debug("\r\n");

    if (LORA_SendCmd_GetResponse(cmd, cmd_len, response, expected_response_len)) {
        // 打印接收到的响应（通过UART5）
        LORA_Debug("[LORA] Response: ");
        for(uint16_t i = 0; i < expected_response_len; i++) {
            byte_to_hex(response[i], hex_buf);
            LORA_Debug_Hex(hex_buf);
        }
        LORA_Debug("\r\n");

        // 校验响应
        if (response[0] == 0xC1 && response[1] == startAddr && response[2] == len) {
            memcpy(pBuffer, &response[3], len);
            LORA_Debug("[LORA] Read SUCCESS!\r\n");
            return true; // 读取成功
        }
        LORA_Debug("[LORA] Read FAILED - Response mismatch!\r\n");
    } else {
        LORA_Debug("[LORA] Read FAILED - No response!\r\n");
    }
    return false; // 失败
}

bool LORA_Set_Broadcast_Address(void) {
    uint8_t address[2] = { 0xFF, 0xFF };
    // 写入 ADDH (0x00) 和 ADDL (0x01)
    return LORA_WriteReg(0x00, 2, address);
}

bool LORA_Set_UART_BaudRate(uint8_t baud_val) {
    uint8_t reg_val;
    // 必须先读出寄存器 0x03 的值, 只修改波特率位 (Bit 7, 6, 5)
    if (LORA_ReadReg(0x03, 1, &reg_val)) {
        // (E22-T22S 寄存器 0x03, 波特率在 Bit[7:5], 校验位在 Bit[4:3])
        // 假设保留原有的校验位 (e.g., 8N1 = 0b00)
        uint8_t parity_bits = reg_val & 0x18; // 保留 Bit[4:3]
        uint8_t air_rate_bits = reg_val & 0x07; // 保留 Bit[2:0]

        reg_val = (baud_val << 5) | parity_bits | air_rate_bits;

        return LORA_WriteReg(0x03, 1, &reg_val);
    }
    return false;
}

/* --- 新增定点传输功能 --- */

bool LORA_Enable_Fixed_Transmission(void) {
    uint8_t reg_val;

    // 1. 读取寄存器 0x06 (REG3) 的当前值 - 定点模式开关在这里！
    if (LORA_ReadReg(0x06, 1, &reg_val)) {

        // 2. 检查第6位是否已经是1 (1=定点模式, 0=透传模式)
        if ((reg_val & 0x40) != 0) {
            return true; // 已经是定点模式，直接返回成功
        }

        // 3. 将第6位置 1，保留其他位不变
        reg_val |= 0x40;

        // 4. 写回寄存器 (使用你现有的 LORA_WriteReg，它是 0xC0 指令，掉电保存)
        return LORA_WriteReg(0x06, 1, &reg_val);
    }
    return false; // 读取失败
}

bool LORA_Disable_Fixed_Transmission(void) {
    uint8_t reg_val;

    // 1. 读取寄存器 0x06 (REG3) 的当前值 - 定点模式开关在这里！
    if (LORA_ReadReg(0x06, 1, &reg_val)) {

        // 2. 检查第6位是否已经是0 (0=透传模式, 1=定点模式)
        if ((reg_val & 0x40) == 0) {
            return true; // 已经是透传模式，直接返回成功
        }

        // 3. 将第6位清零，保留其他位不变
        reg_val &= ~0x40;

        // 4. 写回寄存器 (使用你现有的 LORA_WriteReg，它是 0xC0 指令，掉电保存)
        return LORA_WriteReg(0x06, 1, &reg_val);
    }
    return false; // 读取失败
}

bool LORA_Transmit_Fixed(uint8_t addr_high, uint8_t addr_low, uint8_t channel, uint8_t* pData, uint16_t Size) {
    // 必须定义为 static，因为 DMA 发送是异步的。
    // 如果是局部变量，函数结束时内存会被释放，DMA 就会发乱码。
    static uint8_t fixed_tx_buffer[256];

    // 1. 保护检查：数据太长发不了 (预留3字节给头部)
    if (Size + 3 > sizeof(fixed_tx_buffer)) {
        return false;
    }

    // 2. 确保现在处于模式 0 (透传/正常模式)
    if (!LORA_SetMode(MODE_NORMAL_0)) {
        return false;
    }

    // 3. 等待 AUX 变高 (确保上一包发完了)
    if (!LORA_WaitForAUX(500)) {
        return false;
    }

    // 4. 拼接定点传输的数据包格式
    // 格式：地址高 + 地址低 + 信道 + 用户数据
    fixed_tx_buffer[0] = addr_high;
    fixed_tx_buffer[1] = addr_low;
    fixed_tx_buffer[2] = channel;
    memcpy(&fixed_tx_buffer[3], pData, Size);

    // 5. 使用DMA发送
    USART2_DMA_Transmit(fixed_tx_buffer, Size + 3);

    return true;
}

/**
 * @brief  配置模块的地址和信道 (永久保存)
 * @param  addr: 16位地址 (例如 0x0001)
 * @param  channel: 信道 (0-83)
 * @return true: 配置成功
 */
bool LORA_Set_Address_And_Channel(uint16_t addr, uint8_t channel) {
    bool ret = true;
    uint8_t reg_val;

    // 1. 设置地址 (寄存器 0x00 和 0x01)
    // 0x00 是高8位 (ADDH), 0x01 是低8位 (ADDL)
    uint8_t addr_buffer[2];
    addr_buffer[0] = (addr >> 8) & 0xFF; // 取高8位
    addr_buffer[1] = addr & 0xFF;        // 取低8位

    // 调用你现有的 WriteReg (它会发送 C0 命令，掉电保存)
    if (!LORA_WriteReg(0x00, 2, addr_buffer)) {
        ret = false;
    }

    // 2. 设置网络地址为0 (寄存器 0x02)
    uint8_t netid_buffer[1];
    netid_buffer[0] = 0x00;

    if (!LORA_WriteReg(0x02, 1, netid_buffer)) {
        ret = false;
    }

    // 3. 设置信道 (寄存器 0x05)
    uint8_t chan_buffer[1];
    chan_buffer[0] = channel;

    if (!LORA_WriteReg(0x05, 1, chan_buffer)) {
        ret = false;
    }

    // 4. 透明传输模式：清除寄存器0x06第6位。
    // 透明模式下主程序直接发送用户数据，不再在前面拼接地址和信道。
    if (LORA_ReadReg(0x06, 1, &reg_val)) {
        reg_val &= ~0x40;
        if (!LORA_WriteReg(0x06, 1, &reg_val)) {
            ret = false;
        }
    } else {
        ret = false;
    }

    return ret;
}


