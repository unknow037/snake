/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : LoRa Remote Controller - 遥控器主程序
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LORA.h"
#include "ADC.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MY_ADDR_H       0x00
#define MY_ADDR_L       0x01
#define MY_CHANNEL      5

#define TARGET_ADDR_H   0x00
#define TARGET_ADDR_L   0x01
#define TARGET_CHANNEL  5
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static uint16_t lora_packet_count = 0;
/* USER CODE END PV */
volatile uint32_t adc_dma_buf[4];  
uint8_t lora_tx_buf[64];
/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
 * @brief LoRa 初始化
 */
static void LORA_Device_Init(void)
{
    LORA_Init();
    HAL_Delay(100);

    uint16_t my_addr = (MY_ADDR_H << 8) | MY_ADDR_L;
    if (LORA_Set_Address_And_Channel(my_addr, MY_CHANNEL) && LORA_Disable_Fixed_Transmission()) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"[LORA] Config OK\r\n", 18, 50);
    } else {
        HAL_UART_Transmit(&huart1, (uint8_t *)"[LORA] Config FAIL\r\n", 20, 50);
    }
    HAL_Delay(100);
}

/**
 * @brief 发送控制命令 AA BB CC 给接收机
 */
static void Device_B_Send_Command(void)
{
    uint8_t tx_data[3] = {0xAA, 0xBB, 0xCC};
    USART2_DMA_Transmit(tx_data, 3);

    lora_packet_count++;
    HAL_UART_Transmit(&huart1, (uint8_t *)"[TX] Sent AA BB CC\r\n", 20, 50);

    HAL_Delay(50);
}

/**
 * @brief 按键扫描（PB8，低电平有效）
 */
static uint8_t Button_Scan(void)
{
    static uint8_t button_pressed = 0;
    uint8_t button_event = 0;

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_RESET)
    {
        if (button_pressed == 0)
        {
            HAL_Delay(20);
            if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_RESET)
            {
                button_pressed = 1;
                button_event = 1;
            }
        }
    }
    else
    {
        button_pressed = 0;
    }

    return button_event;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  uint16_t ADC1_number =0;
  uint16_t ADC2_number =0;
  /* USER CODE BEGIN 2 */
  LORA_Device_Init();
  MX_ADC1_Init();
  HAL_ADC_Start_DMA(&hadc1, adc_dma_buf, 4);

  HAL_UART_Transmit(&huart1, (uint8_t *)"[INIT] Press PC8 to send AA BB CC\r\n", 35, 100);
  /* USER CODE END 2 */
 
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	 // 1. 读取ADC DMA采集的4路摇杆数据（直接读取全局缓冲区）
    uint32_t joystick1_X = adc_dma_buf[0];
    uint32_t joystick1_Y = adc_dma_buf[1];
    uint32_t joystick2_X = adc_dma_buf[2];
    uint32_t joystick2_Y = adc_dma_buf[3];

    // 2. 打包数据为LoRa可发送的格式
    snprintf((char*)lora_tx_buf, sizeof(lora_tx_buf),
             "X1:%lu,Y1:%lu,X2:%lu,Y2:%lu",
             joystick1_X, joystick1_Y, joystick2_X, joystick2_Y);

    LORA_Transmit_Broadcast(lora_tx_buf, strlen((char*)lora_tx_buf));
    HAL_Delay(200);
    /* USER CODE BEGIN 3 */
    if (Button_Scan())
    {
        Device_B_Send_Command();
    }

    HAL_Delay(10);
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) {}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
