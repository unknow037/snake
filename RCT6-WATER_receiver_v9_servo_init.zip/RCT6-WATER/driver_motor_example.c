/**
  ******************************************************************************
  * @file    driver_motor_example.c
  * @brief   Usage examples for motor and encoder drivers
  * @author  Example Code
  * @date    2024
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "driver_motor.h"
#include "driver_encoder.h"

/* Private variables ---------------------------------------------------------*/
int encoder_left = 0;
int encoder_right = 0;

/* Timer callback for periodic encoder reading (10ms interval) */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    // Assuming TIM3 is configured as 10ms timer interrupt
    if(htim->Instance == TIM3)
    {
        // Read encoder values
        encoder_left = Driver_Encoder_ReadLeft();
        encoder_right = Driver_Encoder_ReadRight();

        // You can implement speed control PID here
        // Example: maintain constant speed
        // int error = target_speed - encoder_left;
        // int output = Kp * error + Ki * error_sum;
        // Driver_Motor_SetSpeed(output, output);
    }
}

/* Example 1: Basic motor control */
void Example_BasicMotorControl(void)
{
    // Both motors forward at half speed
    Driver_Motor_SetSpeed(3600, 3600);
    HAL_Delay(2000);

    // Stop
    Driver_Motor_Stop();
    HAL_Delay(1000);

    // Both motors backward at quarter speed
    Driver_Motor_SetSpeed(-1800, -1800);
    HAL_Delay(2000);

    // Stop
    Driver_Motor_Stop();
}

/* Example 2: Turning control */
void Example_TurningControl(void)
{
    // Turn right: left motor faster
    Driver_Motor_SetSpeed(4000, 2000);
    HAL_Delay(1000);

    // Turn left: right motor faster
    Driver_Motor_SetSpeed(2000, 4000);
    HAL_Delay(1000);

    // Spin in place: opposite directions
    Driver_Motor_SetSpeed(3000, -3000);
    HAL_Delay(1000);

    Driver_Motor_Stop();
}

/* Example 3: Speed limiting */
void Example_SpeedLimiting(void)
{
    int motor1 = 10000;  // Exceeds max
    int motor2 = -10000; // Exceeds min

    // Apply limits
    Driver_Motor_Limit(&motor1, &motor2);
    // Now motor1 = 7200, motor2 = -7200

    Driver_Motor_SetSpeed(motor1, motor2);
    HAL_Delay(2000);

    Driver_Motor_Stop();
}

/* Example 4: Simple speed control using encoders */
void Example_SpeedControl(void)
{
    int target_speed = 50;  // Target encoder pulses per 10ms
    int motor_speed = 3000; // Initial PWM value

    // This would typically run in a timer interrupt
    for(int i = 0; i < 100; i++)
    {
        // Read encoders
        int left_speed = Driver_Encoder_ReadLeft();
        int right_speed = Driver_Encoder_ReadRight();

        // Simple proportional control
        int error = target_speed - left_speed;
        motor_speed += error * 10;  // Kp = 10

        // Apply limits
        Driver_Motor_Limit(&motor_speed, &motor_speed);

        // Set motor speed
        Driver_Motor_SetSpeed(motor_speed, motor_speed);

        HAL_Delay(10);  // 10ms control loop
    }

    Driver_Motor_Stop();
}

/* Example 5: Straight line correction */
void Example_StraightLineCorrection(void)
{
    int base_speed = 3000;
    int correction_gain = 50;

    for(int i = 0; i < 200; i++)  // Run for 2 seconds
    {
        // Read encoder difference
        int left_enc = Driver_Encoder_ReadLeft();
        int right_enc = Driver_Encoder_ReadRight();
        int difference = left_enc - right_enc;

        // Correct for difference
        int left_motor = base_speed - (difference * correction_gain);
        int right_motor = base_speed + (difference * correction_gain);

        // Apply limits
        Driver_Motor_Limit(&left_motor, &right_motor);

        // Set speeds
        Driver_Motor_SetSpeed(left_motor, right_motor);

        HAL_Delay(10);
    }

    Driver_Motor_Stop();
}

/* Example 6: Integration with original balance car control */
void Example_BalanceCarIntegration(void)
{
    // This would be called in your 10ms timer interrupt

    // Read encoders (matching original code style)
    int Encoder_Left = Driver_Encoder_ReadLeft();
    int Encoder_Right = Driver_Encoder_ReadRight();

    // Your PID control calculations here
    // int Vertical_out = Vertical_PID(...);
    // int Velocity_out = Velocity_PID(...);
    // int Turn_out = Turn_PID(...);

    // Example values
    int MOTO1 = 1500;
    int MOTO2 = 1500;

    // Apply limits
    Driver_Motor_Limit(&MOTO1, &MOTO2);

    // Set motor speeds (replaces original Load() function)
    Driver_Motor_SetSpeed(MOTO1, MOTO2);
}

/* Main function example */
int main(void)
{
    /* MCU Configuration */
    HAL_Init();
    SystemClock_Config();

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_TIM1_Init();  // PWM timer for motors
    MX_TIM2_Init();  // Left encoder
    MX_TIM3_Init();  // 10ms timer interrupt
    MX_TIM4_Init();  // Right encoder

    /* Start PWM channels */
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    /* Start encoders */
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);

    /* Start 10ms timer interrupt for encoder reading */
    HAL_TIM_Base_Start_IT(&htim3);

    /* Initialize motors to stop */
    Driver_Motor_Stop();

    /* Run examples */
    HAL_Delay(1000);

    // Uncomment to test different examples
    // Example_BasicMotorControl();
    // Example_TurningControl();
    // Example_SpeedLimiting();
    // Example_SpeedControl();
    // Example_StraightLineCorrection();

    /* Infinite loop */
    while (1)
    {
        // Your main loop code here
        // Motor control should be done in timer interrupt

        HAL_Delay(100);
    }
}
