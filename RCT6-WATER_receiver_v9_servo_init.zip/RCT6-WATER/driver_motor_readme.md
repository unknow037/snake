# 减速电机驱动移植指南

## 文件说明

本驱动从STM32F103C8T6平衡小车项目中提取,并重新封装为便于移植的driver_前缀文件。

### 生成的文件:
- `driver_motor.h` / `driver_motor.c` - 电机PWM控制驱动
- `driver_encoder.h` / `driver_encoder.c` - 编码器读取驱动

---

## 原始代码分析

### 1. 电机控制 (motor.c/h)

**功能:**
- 控制两个直流减速电机的转速和方向
- PWM范围: -7200 到 +7200
- 使用TIM1的CH1和CH4输出PWM
- 使用GPIO控制电机方向(通过H桥驱动器)

**硬件连接 (原STM32F103C8T6):**
```
电机1 (左轮):
  - PWM: TIM1_CH4 (PA11)
  - 方向: PB13 (正转), PB12 (反转)

电机2 (右轮):
  - PWM: TIM1_CH1 (PA8)
  - 方向: PB14 (正转), PB15 (反转)
```

**关键函数:**
- `Load(int moto1, int moto2)` - 设置两个电机的速度和方向
- `Limit(int *motoA, int *motoB)` - 限制电机PWM值在安全范围内

### 2. 编码器读取 (encoder.c/h)

**功能:**
- 读取两个正交编码器的速度值
- 使用TIM2和TIM4的编码器模式
- 每次读取后自动清零计数器

**硬件连接 (原STM32F103C8T6):**
```
左轮编码器 (TIM2):
  - A相: PA0 (TIM2_CH1)
  - B相: PA1 (TIM2_CH2)

右轮编码器 (TIM4):
  - A相: PB6 (TIM4_CH1)
  - B相: PB7 (TIM4_CH2)
```

**关键函数:**
- `Read_Speed(TIM_HandleTypeDef *htim)` - 读取编码器计数并清零

### 3. 定时器配置 (tim.c)

**TIM1 - PWM输出:**
- 预分频: 0
- 周期: 7199 (ARR)
- PWM频率: 72MHz / 7200 = 10kHz
- 模式: PWM模式1

**TIM2/TIM4 - 编码器模式:**
- 预分频: 0
- 周期: 65535
- 编码器模式: TI12 (4倍频)
- 两个通道都配置为输入捕获

---

## 移植到STM32F103RCT6步骤

### 步骤1: 使用CubeMX配置定时器

#### 配置PWM定时器 (推荐TIM1或TIM8):
1. 选择一个高级定时器(TIM1/TIM8)或通用定时器(TIM2-TIM5)
2. 配置两个通道为PWM输出模式
3. 参数设置:
   - Prescaler: 0
   - Counter Period (ARR): 7199
   - Pulse: 0
   - PWM Mode: Mode 1

#### 配置编码器定时器 (推荐TIM2, TIM3, TIM4, TIM5):
1. 选择两个定时器用于编码器
2. 配置为Combined Channels模式 → Encoder Mode
3. 参数设置:
   - Prescaler: 0
   - Counter Period: 65535
   - Encoder Mode: TI1 and TI2
   - Input Filter: 根据需要设置(0-15)

### 步骤2: 修改driver_motor.h配置

```c
// 1. 修改定时器句柄
#define MOTOR_TIM_HANDLE      htim1  // 改为你的PWM定时器

// 2. 修改PWM通道
#define MOTOR1_TIM_CHANNEL    TIM_CHANNEL_4  // 改为你的通道
#define MOTOR2_TIM_CHANNEL    TIM_CHANNEL_1  // 改为你的通道

// 3. 修改方向控制GPIO
#define MOTOR1_DIR_GPIO_PORT  GPIOB
#define MOTOR1_DIR_PIN_FWD    GPIO_PIN_13
#define MOTOR1_DIR_PIN_REV    GPIO_PIN_12

#define MOTOR2_DIR_GPIO_PORT  GPIOB
#define MOTOR2_DIR_PIN_FWD    GPIO_PIN_14
#define MOTOR2_DIR_PIN_REV    GPIO_PIN_15
```

### 步骤3: 修改driver_encoder.h配置

```c
// 修改编码器定时器句柄
#define ENCODER_LEFT_TIM       htim2  // 改为你的左编码器定时器
#define ENCODER_RIGHT_TIM      htim4  // 改为你的右编码器定时器
```

### 步骤4: 在main.c中初始化

```c
#include "driver_motor.h"
#include "driver_encoder.h"

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    // 初始化外设(CubeMX生成的函数)
    MX_GPIO_Init();
    MX_TIM1_Init();  // PWM定时器
    MX_TIM2_Init();  // 左编码器
    MX_TIM4_Init();  // 右编码器

    // 启动PWM
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    // 启动编码器
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);

    // 停止电机
    Driver_Motor_Stop();

    while(1)
    {
        // 你的代码
    }
}
```

### 步骤5: 使用示例

```c
// 示例1: 基本电机控制
int speed1 = 3000;  // 左轮正转,速度3000
int speed2 = 3000;  // 右轮正转,速度3000

Driver_Motor_SetSpeed(speed1, speed2);

// 示例2: 转向
int left_speed = 2000;   // 左轮慢速
int right_speed = 4000;  // 右轮快速(右转)

Driver_Motor_SetSpeed(left_speed, right_speed);

// 示例3: 读取编码器(在定时中断中,每10ms)
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM3)  // 假设使用TIM3作为10ms定时器
    {
        int encoder_left = Driver_Encoder_ReadLeft();
        int encoder_right = Driver_Encoder_ReadRight();

        // 使用编码器值进行速度控制或里程计算
        printf("Left: %d, Right: %d\r\n", encoder_left, encoder_right);
    }
}

// 示例4: 速度限幅
int motor1 = 9000;  // 超过最大值
int motor2 = -9000; // 超过最小值

Driver_Motor_Limit(&motor1, &motor2);
// 现在 motor1 = 7200, motor2 = -7200

Driver_Motor_SetSpeed(motor1, motor2);
```

---

## 引脚映射参考 (STM32F103RCT6)

STM32F103RCT6比C8T6有更多引脚和资源,推荐映射:

### 选项1 (使用TIM1):
```
PWM输出:
  - TIM1_CH1: PA8
  - TIM1_CH4: PA11

编码器1 (TIM2):
  - TIM2_CH1: PA0
  - TIM2_CH2: PA1

编码器2 (TIM4):
  - TIM4_CH1: PB6
  - TIM4_CH2: PB7

方向控制GPIO:
  - 电机1: PB12, PB13
  - 电机2: PB14, PB15
```

### 选项2 (使用TIM8 - 更多可用引脚):
```
PWM输出 (TIM8):
  - TIM8_CH1: PC6
  - TIM8_CH2: PC7

编码器1 (TIM3):
  - TIM3_CH1: PA6
  - TIM3_CH2: PA7

编码器2 (TIM5):
  - TIM5_CH1: PA0
  - TIM5_CH2: PA1

方向控制GPIO:
  - 电机1: PB0, PB1
  - 电机2: PB10, PB11
```

---

## 原理说明

### PWM电机控制原理:
1. **方向控制**: 通过2个GPIO控制H桥
   - (1,0): 正转
   - (0,1): 反转
   - (0,0)或(1,1): 刹车/停止

2. **速度控制**: PWM占空比控制电机电压
   - PWM值越大,占空比越高,速度越快
   - 使用绝对值设置PWM,符号决定方向

### 编码器测速原理:
1. **正交编码器**: A、B两相信号相位差90度
2. **4倍频模式**: TI12模式捕获上升沿和下降沿
3. **方向识别**: 根据A/B相位关系自动加减计数
4. **速度计算**:
   - 固定时间(如10ms)读取计数值
   - 速度 = 计数值 / 时间间隔

---

## 注意事项

1. **定时器选择**:
   - PWM定时器频率要足够高(推荐10kHz以上)
   - 编码器定时器要支持编码器模式(TIM2-5)

2. **编码器方向**:
   - 如果电机转向相反,调整`Driver_Encoder_ReadRight()`的符号
   - 或在CubeMX中调整编码器极性

3. **PWM范围**:
   - 当前设置为±7200,对应ARR=7199
   - 如需调整,同步修改`MOTOR_PWM_MAX/MIN`和TIM ARR值

4. **电源和驱动**:
   - 确保电机驱动板电源充足
   - GPIO输出可能需要加驱动芯片(如ULN2003)

5. **调试建议**:
   - 先测试单个电机
   - 检查编码器方向是否正确
   - 使用示波器检查PWM波形

---

## API参考

### 电机控制API:

| 函数 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `Driver_Motor_SetSpeed()` | motor1_speed, motor2_speed | void | 设置两个电机速度 |
| `Driver_Motor_Limit()` | *motor1_speed, *motor2_speed | void | 限制速度值范围 |
| `Driver_Motor_Stop()` | void | void | 紧急停止 |

### 编码器API:

| 函数 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `Driver_Encoder_Read()` | *htim | int | 读取指定编码器 |
| `Driver_Encoder_ReadLeft()` | void | int | 读取左编码器 |
| `Driver_Encoder_ReadRight()` | void | int | 读取右编码器 |
| `Driver_Encoder_Reset()` | *htim | void | 复位编码器计数 |

---

## 常见问题

**Q1: 电机不转?**
- 检查PWM定时器是否启动
- 检查GPIO方向控制引脚配置
- 用万用表测量驱动板输出电压

**Q2: 编码器读数始终为0?**
- 检查编码器定时器是否启动
- 确认引脚配置为编码器模式(非GPIO)
- 手动转动电机,观察TIM计数器是否变化

**Q3: 电机转向相反?**
- 交换方向控制GPIO的FWD和REV引脚定义
- 或在代码中取反速度值

**Q4: 编码器计数不准确?**
- 调整输入滤波器参数(IC1Filter/IC2Filter)
- 检查编码器供电和信号质量
- 确认编码器线数和倍频设置

---

## 版本历史

- v1.0 (2024): 初始版本,从平衡小车项目移植
  - 支持双电机PWM控制
  - 支持双编码器读取
  - 添加详细注释和移植指南
