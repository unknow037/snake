/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;

extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */

/* USART1接收缓冲区大小定义 */
#define USART1_RX_BUFFER_SIZE 256
/* USART2接收缓冲区大小定义 */
#define USART2_RX_BUFFER_SIZE 256

/* USART1的DMA句柄声明 */
extern DMA_HandleTypeDef hdma_usart1_rx;
extern DMA_HandleTypeDef hdma_usart1_tx;

/* USART2的DMA句柄声明 */
extern DMA_HandleTypeDef hdma_usart2_rx;
extern DMA_HandleTypeDef hdma_usart2_tx;

/* USART1接收缓冲区相关声明 */
extern uint8_t usart1_rx_buffer[];
extern volatile uint8_t usart1_data_received;
extern volatile uint16_t usart1_rx_size;
extern volatile uint8_t usart1_tx_busy;

/* USART2接收缓冲区相关声明 */
extern uint8_t usart2_rx_buffer[];
extern volatile uint8_t usart2_data_received;
extern volatile uint16_t usart2_rx_size;
extern volatile uint8_t usart2_tx_busy;

/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */

/* USART1 DMA传输和接收函数 */
void USART1_DMA_Transmit(uint8_t *pData, uint16_t Size);
void USART1_DMA_Receive(uint8_t *pData, uint16_t Size);

/* USART2 DMA传输和接收函数 */
void USART2_DMA_Transmit(uint8_t *pData, uint16_t Size);
void USART2_DMA_Receive(uint8_t *pData, uint16_t Size);

/* USART1空闲中断回调函数 */
void USART1_IDLE_Callback(void);

/* USART2空闲中断回调函数 */
void USART2_IDLE_Callback(void);

/* USART1字符串发送函数 */
void USART1_Send_String(const char* str);

/* USART1格式化发送函数（类似printf） */
void USART1_Printf(const char* format, ...);

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

