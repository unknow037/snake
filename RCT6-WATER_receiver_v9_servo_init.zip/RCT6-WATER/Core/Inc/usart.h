/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart4;

extern UART_HandleTypeDef huart5;

extern UART_HandleTypeDef huart1;

extern UART_HandleTypeDef huart2;

extern UART_HandleTypeDef huart3;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

void MX_UART4_Init(void);
void MX_UART5_Init(void);
void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);
void MX_USART3_UART_Init(void);

/* USER CODE BEGIN Prototypes */

// USART1 接收缓冲区和函数
extern uint8_t RxBuffer[200];
extern volatile uint8_t RxDataLen;
extern volatile uint8_t RecieveFlag;
void Usart1_SendString(uint8_t *content);

// USART2 接收缓冲区和函数（LORA专用）
extern uint8_t RxBuffer2[200];
extern volatile uint8_t RxDataLen2;
extern volatile uint8_t RecieveFlag2;
extern volatile uint8_t usart2_tx_busy;
void Usart2_SendString(uint8_t *content);
void USART2_DMA_Transmit(uint8_t *pData, uint16_t Size);
void USART2_DMA_Receive(uint8_t *pData, uint16_t Size);
void USART2_IDLE_Callback(void);

// USART3 接收缓冲区和函数
extern uint8_t RxBuffer3[200];
extern volatile uint8_t RxDataLen3;
extern volatile uint8_t RecieveFlag3;
void Usart3_SendString(uint8_t *content);

// UART4 接收缓冲区和函数
extern uint8_t RxBuffer4[200];
extern volatile uint8_t RxDataLen4;
extern volatile uint8_t RecieveFlag4;
void Uart4_SendString(uint8_t *content);

// UART5 接收缓冲区和函数
extern uint8_t RxBuffer5[200];
extern volatile uint8_t RxDataLen5;
extern volatile uint8_t RecieveFlag5;
void Uart5_SendString(uint8_t *content);

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

