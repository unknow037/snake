#ifndef LORA_H
#define LORA_H

#include "main.h" // 假设您的 HAL 库头文件和引脚定义在 main.h
#include <stdint.h>
#include <stdbool.h>

// 假设 UART 句柄由 CubeMX 生成
extern UART_HandleTypeDef huart2;
// USART2 DMA 接收缓冲区 (在 usart.c 中定义)
extern uint8_t RxBuffer2[];

// LORA (E22) 工作模式
typedef enum {
    MODE_NORMAL_0 = 0, // 透传模式
    MODE_WOR_1 = 1,      // WOR 模式
    MODE_CONFIG_2 = 2, // 配置模式
    MODE_SLEEP_3 = 3   // 深度休眠
} LORA_Mode;

// 定义您在透传模式下希望使用的波特率
#define LORA_NORMAL_BAUD_RATE 9600
// 配置模式固定波特率
#define LORA_CONFIG_BAUD_RATE 9600
// USART2 接收缓冲区大小
#define USART2_RX_BUFFER_SIZE 200

/**
 * @brief 初始化 LORA (E22) 模块
 * @note 复位模块, 等待 AUX 就绪, 并设置为透传模式 (MODE_NORMAL_0)
 */
void LORA_Init(void);

/**
 * @brief 硬复位 LORA (E22) 模块
 * @note 拉低 RESET 引脚 5ms, 然后等待 AUX 变高
 */
void LORA_Reset(void);

/**
 * @brief 设置 LORA (E22) 的工作模式
 * @note 通过 M0 (PA4) 和 M1 (PA5) 引脚设置
 * @param mode: 要设置的目标模式
 * @return true: 切换成功 (AUX 响应正常)
 * @return false: 切换失败 (AUX 超时)
 */
bool LORA_SetMode(LORA_Mode mode);

/**
 * @brief (透传模式) 发送广播数据
 * @note 必须先使用 LORA_Set_Broadcast_Address() 将模块配置为广播地址 0xFFFF
 * @param pData: 数据缓冲区指针
 * @param Size: 数据长度
 * @return true: 发送请求成功 (已交由 DMA)
 * @return false: 发送失败 (模块繁忙或切换模式失败)
 */
bool LORA_Transmit_Broadcast(uint8_t* pData, uint16_t Size);

/**
 * @brief (配置模式) 写寄存器 (掉电保存)
 * @note 自动切换到配置模式 (9600bps), 发送 C0 指令, 然后切换回透传模式
 * @param startAddr: 寄存器起始地址
 * @param len: 要写入的数据长度
 * @param pData: 写入的数据
 * @return true: 写入成功 (收到 C1 响应且内容一致)
 * @return false: 写入失败 (超时或响应错误)
 */
bool LORA_WriteReg(uint8_t startAddr, uint8_t len, uint8_t* pData);

/**
 * @brief (配置模式) 读寄存器
 * @note 自动切换到配置模式 (9600bps), 发送 C1 指令, 然后切换回透传模式
 * @param startAddr: 寄存器起始地址
 * @param len: 要读取的数据长度
 * @param pBuffer: 存放读取数据的缓冲区
 * @return true: 读取成功
 * @return false: 读取失败
 */
bool LORA_ReadReg(uint8_t startAddr, uint8_t len, uint8_t* pBuffer);

/**
 * @brief (配置模式) 示例函数：将模块地址配置为 0xFFFF (广播/监听地址)
 * @return true: 配置成功
 * @return false: 配置失败
 */
bool LORA_Set_Broadcast_Address(void);

/**
 * @brief (配置模式) 示例函数：设置模块的透传波特率
 * @note 修改寄存器 0x03
 * @param baud_val: 对应手册 7.2 节的波特率值 (e.g., 115200 对应 0x07)
 * @return true: 配置成功
 * @return false: 配置失败
 */
bool LORA_Set_UART_BaudRate(uint8_t baud_val);

/**
 * @brief  [配置模式] 开启定点传输模式
 * @note   只需调用一次，配置会掉电保存。
 * 修改寄存器 0x04 的第 6 位为 1。
 * @return true: 配置成功
 */
bool LORA_Enable_Fixed_Transmission(void);

/**
 * @brief  [配置模式] 关闭定点传输模式（恢复透传模式）
 * @note   只需调用一次，配置会掉电保存。
 * 修改寄存器 0x04 的第 6 位为 0。
 * @return true: 配置成功
 */
bool LORA_Disable_Fixed_Transmission(void);

/**
 * @brief  [透传模式] 定点发送数据
 * @note   自动在数据前拼接目标地址和信道。发送方无需切换信道。
 * @param  addr_high: 目标设备的高8位地址 (ADDH)
 * @param  addr_low:  目标设备的低8位地址 (ADDL)
 * @param  channel:   目标设备的信道 (0-83)
 * @param  pData:     要发送的数据缓冲区
 * @param  Size:      数据长度
 * @return true: 发送请求成功 (已交给 DMA)
 */
bool LORA_Transmit_Fixed(uint8_t addr_high, uint8_t addr_low, uint8_t channel, uint8_t* pData, uint16_t Size);



bool LORA_Set_Address_And_Channel(uint16_t addr, uint8_t channel);

#endif // LORA_H
