/**
  ******************************************************************************
  * @file    driver_encoder.h
  * @brief   Quadrature Encoder Driver for STM32F103 (Portable Version)
  * @author  Ported from original balance car project
  * @date    2024
  ******************************************************************************
  * @description
  * This driver reads speed from quadrature encoders using STM32 timer
  * encoder mode. Two encoders are typically used for left and right wheels.
  *
  * Hardware Requirements:
  *   - Two timers with encoder mode capability (e.g., TIM2, TIM4)
  *   - Each encoder uses 2 channels (A and B phase signals)
  *
  * Configuration:
  *   - Update ENCODER_LEFT_TIM and ENCODER_RIGHT_TIM below
  *   - Encoder mode should be configured in CubeMX or manually
  *   - Period should be set to 65535 for maximum range
  *
  * Usage:
  *   Call Driver_Encoder_Read() periodically (e.g., every 10ms)
  *   Returns encoder count since last read (speed measurement)
  ******************************************************************************
  */

#ifndef __DRIVER_ENCODER_H
#define __DRIVER_ENCODER_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Configuration Macros ------------------------------------------------------*/
// Left Encoder Timer
// TODO: Update to match your STM32F103RCT6 configuration
#define ENCODER_LEFT_TIM       htim2

// Right Encoder Timer
// TODO: Update to match your STM32F103RCT6 configuration
#define ENCODER_RIGHT_TIM      htim4

/* External Variables --------------------------------------------------------*/
// Timer handles should be defined in your tim.c file
extern TIM_HandleTypeDef ENCODER_LEFT_TIM;
extern TIM_HandleTypeDef ENCODER_RIGHT_TIM;

/* Function Prototypes -------------------------------------------------------*/

/**
  * @brief  Read encoder speed (count since last read)
  * @param  htim: Pointer to timer handle configured in encoder mode
  * @retval Encoder count value (signed 16-bit)
  * @note   Counter is automatically reset to 0 after reading
  * @note   Return value is signed to indicate rotation direction:
  *         - Positive: Forward rotation
  *         - Negative: Backward rotation
  */
int Driver_Encoder_Read(TIM_HandleTypeDef *htim);

/**
  * @brief  Read left encoder speed
  * @param  None
  * @retval Encoder count (pulses since last read)
  */
int Driver_Encoder_ReadLeft(void);

/**
  * @brief  Read right encoder speed
  * @param  None
  * @retval Encoder count (pulses since last read)
  * @note   May need sign inversion depending on motor/encoder orientation
  */
int Driver_Encoder_ReadRight(void);

/**
  * @brief  Reset encoder counter to zero
  * @param  htim: Pointer to timer handle
  * @retval None
  */
void Driver_Encoder_Reset(TIM_HandleTypeDef *htim);

#ifdef __cplusplus
}
#endif

#endif /* __DRIVER_ENCODER_H */
