/**
  ******************************************************************************
  * @file    driver_motor.h
  * @brief   DC Motor Driver for STM32F103 (Portable Version)
  * @author  Ported from original balance car project
  * @date    2024
  ******************************************************************************
  * @description
  * This driver controls two DC motors with direction and PWM speed control.
  *
  * Hardware Requirements:
  *   - TIM with PWM capability (e.g., TIM1)
  *   - 4 GPIO pins for direction control (2 per motor)
  *   - Motor driver board (e.g., L298N, TB6612)
  *
  * Configuration:
  *   - Modify MOTOR_TIM_HANDLE to match your timer
  *   - Update motor channel and GPIO definitions below
  *   - PWM range: -7200 to +7200 (adjustable via PWM_MAX/PWM_MIN)
  ******************************************************************************
  */

#ifndef __DRIVER_MOTOR_H
#define __DRIVER_MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Configuration Macros ------------------------------------------------------*/
// PWM Limits
#define MOTOR_PWM_MAX         7200
#define MOTOR_PWM_MIN        -7200

// Timer Configuration
// TODO: Update this to match your STM32F103RCT6 timer configuration
#define MOTOR_TIM_HANDLE      htim1

// Motor 1 (Left Motor) - PWM Channel
// TODO: Update to match your hardware connection
#define MOTOR1_TIM_CHANNEL    TIM_CHANNEL_4

// Motor 1 (Left Motor) - Direction Control GPIOs
// TODO: Update to match your hardware connection
#define MOTOR1_DIR_GPIO_PORT  GPIOB
#define MOTOR1_DIR_PIN_FWD    GPIO_PIN_13  // Forward direction
#define MOTOR1_DIR_PIN_REV    GPIO_PIN_12  // Reverse direction

// Motor 2 (Right Motor) - PWM Channel
// TODO: Update to match your hardware connection
#define MOTOR2_TIM_CHANNEL    TIM_CHANNEL_1

// Motor 2 (Right Motor) - Direction Control GPIOs
// TODO: Update to match your hardware connection
#define MOTOR2_DIR_GPIO_PORT  GPIOB
#define MOTOR2_DIR_PIN_FWD    GPIO_PIN_14  // Forward direction
#define MOTOR2_DIR_PIN_REV    GPIO_PIN_15  // Reverse direction

/* External Variables --------------------------------------------------------*/
// Timer handle should be defined in your tim.c file
extern TIM_HandleTypeDef MOTOR_TIM_HANDLE;

/* Function Prototypes -------------------------------------------------------*/

/**
  * @brief  Set motor speed and direction for both motors
  * @param  motor1_speed: Speed for motor 1 (-7200 to +7200)
  *                       Positive = Forward, Negative = Reverse
  * @param  motor2_speed: Speed for motor 2 (-7200 to +7200)
  *                       Positive = Forward, Negative = Reverse
  * @retval None
  * @note   Values are automatically limited to MOTOR_PWM_MIN/MAX range
  */
void Driver_Motor_SetSpeed(int motor1_speed, int motor2_speed);

/**
  * @brief  Limit motor speed values to valid range
  * @param  motor1_speed: Pointer to motor 1 speed value
  * @param  motor2_speed: Pointer to motor 2 speed value
  * @retval None
  * @note   This function modifies the values through pointers
  */
void Driver_Motor_Limit(int *motor1_speed, int *motor2_speed);

/**
  * @brief  Stop both motors immediately
  * @param  None
  * @retval None
  */
void Driver_Motor_Stop(void);

/**
  * @brief  Get absolute value (internal utility)
  * @param  value: Input integer value
  * @retval Absolute value
  */
int Driver_Motor_Abs(int value);

#ifdef __cplusplus
}
#endif

#endif /* __DRIVER_MOTOR_H */
