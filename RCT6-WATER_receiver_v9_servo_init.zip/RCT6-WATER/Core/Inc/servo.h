#ifndef __SERVO_H
#define __SERVO_H

#include "main.h"
#include "usart.h"

// --- 广播地址定义 ---
#define SERVO_BROADCAST_ID    254  // 广播地址,所有舵机执行但不返回应答

// --- 运动控制类指令 ---
#define SERVO_MOVE_TIME_WRITE        1   // 匀速转动到指定角度(立即执行)
#define SERVO_MOVE_TIME_WAIT_WRITE   7   // 预设位置(等待触发)
#define SERVO_MOVE_START             11  // 触发预设动作
#define SERVO_MOVE_STOP              12  // 立即停止在当前位置

// --- 舵机配置类指令 ---
#define SERVO_ID_WRITE               13  // 修改舵机ID
#define SERVO_ANGLE_OFFSET_ADJUST    17  // 角度偏差调整(实时,不保存)
#define SERVO_ANGLE_OFFSET_WRITE     18  // 保存角度偏差
#define SERVO_ANGLE_LIMIT_WRITE      20  // 设置角度限位
#define SERVO_VIN_LIMIT_WRITE        22  // 设置电压限位
#define SERVO_TEMP_MAX_LIMIT_WRITE   24  // 设置温度上限

// --- 读取类指令 ---
#define SERVO_TEMP_READ              26  // 读取实时温度
#define SERVO_VIN_READ               27  // 读取实时电压
#define SERVO_POS_READ               28  // 读取当前实际角度位置
#define SERVO_ID_READ                14  // 读取舵机ID
#define SERVO_ANGLE_LIMIT_READ       21  // 读取角度限位
#define SERVO_MODE_READ              30  // 读取当前模式

// --- 模式与状态类指令 ---
#define SERVO_OR_MOTOR_MODE_WRITE    29  // 切换舵机/电机模式
#define SERVO_LOAD_OR_UNLOAD_WRITE   31  // 力矩装载/卸载
#define SERVO_LED_CTRL_WRITE         33  // LED控制
#define SERVO_LED_ERROR_WRITE        35  // LED报警设置

// --- 模式定义 ---
#define SERVO_MODE_POSITION          0   // 位置伺服模式
#define SERVO_MODE_MOTOR             1   // 电机模式(连续转动)

// --- LED控制定义 ---
#define SERVO_LED_ON                 0   // LED常亮
#define SERVO_LED_OFF                1   // LED常灭

// --- LED报警项定义 ---
#define SERVO_LED_ERROR_OVER_TEMP    1   // 过温报警
#define SERVO_LED_ERROR_OVER_VOLTAGE 2   // 过压报警
#define SERVO_LED_ERROR_LOCKED_ROTOR 4   // 堵转报警

// --- 函数声明 ---

// 注意: 硬件采用74HC126+NPN自动收发切换,无需软件控制GPIO

// 基础函数
uint8_t Servo_CheckSum(uint8_t id, uint8_t len, uint8_t cmd, uint8_t *prms, uint8_t prm_count);

// 运动控制函数
void Servo_Move(uint8_t id, uint16_t angle, uint16_t time);
void Servo_MoveWait(uint8_t id, uint16_t angle, uint16_t time);
void Servo_MoveStart(uint8_t id);
void Servo_MoveStop(uint8_t id);

// 电机模式控制函数
void Servo_SetMode(uint8_t id, uint8_t mode, int16_t speed);
void Servo_MotorMode(uint8_t id, int16_t speed);

// 力矩控制函数
void Servo_SetTorque(uint8_t id, uint8_t isEnable);

// 配置类函数
void Servo_SetID(uint8_t oldID, uint8_t newID);
void Servo_SetAngleOffset(uint8_t id, int8_t offset);
void Servo_SaveAngleOffset(uint8_t id);
void Servo_SetAngleLimit(uint8_t id, uint16_t minAngle, uint16_t maxAngle);
void Servo_SetVinLimit(uint8_t id, uint16_t minVoltage, uint16_t maxVoltage);
void Servo_SetTempLimit(uint8_t id, uint8_t maxTemp);

// 读取类函数
void Servo_ReadPosition(uint8_t id);
void Servo_ReadVoltage(uint8_t id);
void Servo_ReadTemperature(uint8_t id);
void Servo_ReadID(uint8_t id);
void Servo_ReadAngleLimit(uint8_t id);
void Servo_ReadMode(uint8_t id);

// LED控制函数
void Servo_SetLED(uint8_t id, uint8_t ledState);
void Servo_SetLEDError(uint8_t id, uint8_t errorMask);

#endif
