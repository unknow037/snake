#include "servo.h"

/**
 * @brief 计算校验和
 * 计算方法：~(ID + Length + Cmd + Prm1 + ... PrmN)
 */
uint8_t Servo_CheckSum(uint8_t id, uint8_t len, uint8_t cmd, uint8_t *prms, uint8_t prm_count) {
    uint32_t sum = id + len + cmd;
    for (uint8_t i = 0; i < prm_count; i++) {
        sum += prms[i];
    }
    return (uint8_t)(~sum); // 取反
}

// ========== 运动控制类函数 ==========

/**
 * @brief 舵机位置控制(立即执行)
 * @param id 舵机ID (1-253) 或 254(广播)
 * @param angle 0~1000 (对应 0~240度)
 * @param time 0~30000ms (运行时间)
 */
void Servo_Move(uint8_t id, uint16_t angle, uint16_t time) {
    uint8_t prms[4];
    prms[0] = (uint8_t)(angle & 0xFF);         // 角度低8位
    prms[1] = (uint8_t)((angle >> 8) & 0xFF);  // 角度高8位
    prms[2] = (uint8_t)(time & 0xFF);          // 时间低8位
    prms[3] = (uint8_t)((time >> 8) & 0xFF);   // 时间高8位

    uint8_t data[10] = {0x55, 0x55, id, 7, SERVO_MOVE_TIME_WRITE,
                        prms[0], prms[1], prms[2], prms[3]};
    data[9] = Servo_CheckSum(id, 7, SERVO_MOVE_TIME_WRITE, prms, 4);

    HAL_UART_Transmit(&huart3, data, 10, 100);
}

/**
 * @brief 舵机位置控制(预设,等待触发)
 * @param id 舵机ID (1-253) 或 254(广播)
 * @param angle 0~1000 (对应 0~240度)
 * @param time 0~30000ms (运行时间)
 * @note 需要配合 Servo_MoveStart() 触发执行
 */
void Servo_MoveWait(uint8_t id, uint16_t angle, uint16_t time) {
    uint8_t prms[4];
    prms[0] = (uint8_t)(angle & 0xFF);
    prms[1] = (uint8_t)((angle >> 8) & 0xFF);
    prms[2] = (uint8_t)(time & 0xFF);
    prms[3] = (uint8_t)((time >> 8) & 0xFF);

    uint8_t data[10] = {0x55, 0x55, id, 7, SERVO_MOVE_TIME_WAIT_WRITE,
                        prms[0], prms[1], prms[2], prms[3]};
    data[9] = Servo_CheckSum(id, 7, SERVO_MOVE_TIME_WAIT_WRITE, prms, 4);

    HAL_UART_Transmit(&huart3, data, 10, 100);
}

/**
 * @brief 触发预设动作(配合MoveWait使用)
 * @param id 舵机ID (1-253) 或 254(广播)
 */
void Servo_MoveStart(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_MOVE_START};
    data[5] = Servo_CheckSum(id, 3, SERVO_MOVE_START, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 立即停止舵机运动
 * @param id 舵机ID (1-253) 或 254(广播)
 */
void Servo_MoveStop(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_MOVE_STOP};
    data[5] = Servo_CheckSum(id, 3, SERVO_MOVE_STOP, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

// ========== 电机模式控制函数 ==========

/**
 * @brief 设置舵机/电机模式
 * @param id 舵机ID (1-253)
 * @param mode 0=位置伺服模式, 1=电机模式(连续转动)
 * @param speed 速度值
 *        - 位置模式: 0~1000 (角速度)
 *        - 电机模式: -1000~1000 (负数反转,正数正转,0停止)
 */
void Servo_SetMode(uint8_t id, uint8_t mode, int16_t speed) {
    uint8_t prms[4];
    prms[0] = mode;  // 模式: 0=舵机, 1=电机
    prms[1] = 0;     // 保留字节
    prms[2] = (uint8_t)(speed & 0xFF);         // 速度低8位
    prms[3] = (uint8_t)((speed >> 8) & 0xFF);  // 速度高8位

    uint8_t data[10] = {0x55, 0x55, id, 7, SERVO_OR_MOTOR_MODE_WRITE,
                        prms[0], prms[1], prms[2], prms[3]};
    data[9] = Servo_CheckSum(id, 7, SERVO_OR_MOTOR_MODE_WRITE, prms, 4);

    HAL_UART_Transmit(&huart3, data, 10, 100);
}

/**
 * @brief 电机模式快捷控制(自动切换到电机模式并设置速度)
 * @param id 舵机ID (1-253)
 * @param speed -1000~1000 (负数反转,正数正转,0停止)
 */
void Servo_MotorMode(uint8_t id, int16_t speed) {
    Servo_SetMode(id, SERVO_MODE_MOTOR, speed);
}

// ========== 力矩控制函数 ==========

/**
 * @brief 设置舵机力矩装载/卸载
 * @param id 舵机ID (1-253) 或 254(广播)
 * @param isEnable 1:装载(有力), 0:卸载(无力)
 */
void Servo_SetTorque(uint8_t id, uint8_t isEnable) {
    uint8_t prm = isEnable ? 1 : 0;
    uint8_t data[7] = {0x55, 0x55, id, 4, SERVO_LOAD_OR_UNLOAD_WRITE, prm};
    data[6] = Servo_CheckSum(id, 4, SERVO_LOAD_OR_UNLOAD_WRITE, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);  // 改为UART3
}

// ========== 配置类函数 ==========

/**
 * @brief 修改舵机ID
 * @param oldID 当前ID (1-253) 或 254(广播查找)
 * @param newID 新ID (1-253)
 * @note 该设置会掉电保存
 */
void Servo_SetID(uint8_t oldID, uint8_t newID) {
    uint8_t prm = newID;
    uint8_t data[7] = {0x55, 0x55, oldID, 4, SERVO_ID_WRITE, prm};
    data[6] = Servo_CheckSum(oldID, 4, SERVO_ID_WRITE, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);
}

/**
 * @brief 角度偏差调整(实时调整,不保存)
 * @param id 舵机ID (1-253)
 * @param offset 偏差值 -125~125
 */
void Servo_SetAngleOffset(uint8_t id, int8_t offset) {
    uint8_t prm = (uint8_t)offset;
    uint8_t data[7] = {0x55, 0x55, id, 4, SERVO_ANGLE_OFFSET_ADJUST, prm};
    data[6] = Servo_CheckSum(id, 4, SERVO_ANGLE_OFFSET_ADJUST, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);
}

/**
 * @brief 保存当前角度偏差
 * @param id 舵机ID (1-253)
 * @note 将通过 Servo_SetAngleOffset() 调整的偏差值保存到Flash
 */
void Servo_SaveAngleOffset(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_ANGLE_OFFSET_WRITE};
    data[5] = Servo_CheckSum(id, 3, SERVO_ANGLE_OFFSET_WRITE, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 设置角度限位
 * @param id 舵机ID (1-253)
 * @param minAngle 最小角度 0~1000
 * @param maxAngle 最大角度 0~1000
 * @note 该设置会掉电保存
 */
void Servo_SetAngleLimit(uint8_t id, uint16_t minAngle, uint16_t maxAngle) {
    uint8_t prms[4];
    prms[0] = (uint8_t)(minAngle & 0xFF);
    prms[1] = (uint8_t)((minAngle >> 8) & 0xFF);
    prms[2] = (uint8_t)(maxAngle & 0xFF);
    prms[3] = (uint8_t)((maxAngle >> 8) & 0xFF);

    uint8_t data[10] = {0x55, 0x55, id, 7, SERVO_ANGLE_LIMIT_WRITE,
                        prms[0], prms[1], prms[2], prms[3]};
    data[9] = Servo_CheckSum(id, 7, SERVO_ANGLE_LIMIT_WRITE, prms, 4);

    HAL_UART_Transmit(&huart3, data, 10, 100);
}

/**
 * @brief 设置电压限位
 * @param id 舵机ID (1-253)
 * @param minVoltage 最小电压 4500~14000 (单位mV)
 * @param maxVoltage 最大电压 4500~14000 (单位mV)
 * @note 该设置会掉电保存
 */
void Servo_SetVinLimit(uint8_t id, uint16_t minVoltage, uint16_t maxVoltage) {
    uint8_t prms[4];
    prms[0] = (uint8_t)(minVoltage & 0xFF);
    prms[1] = (uint8_t)((minVoltage >> 8) & 0xFF);
    prms[2] = (uint8_t)(maxVoltage & 0xFF);
    prms[3] = (uint8_t)((maxVoltage >> 8) & 0xFF);

    uint8_t data[10] = {0x55, 0x55, id, 7, SERVO_VIN_LIMIT_WRITE,
                        prms[0], prms[1], prms[2], prms[3]};
    data[9] = Servo_CheckSum(id, 7, SERVO_VIN_LIMIT_WRITE, prms, 4);

    HAL_UART_Transmit(&huart3, data, 10, 100);
}

/**
 * @brief 设置温度上限
 * @param id 舵机ID (1-253)
 * @param maxTemp 最高温度限制 50~100 (单位℃)
 * @note 该设置会掉电保存
 */
void Servo_SetTempLimit(uint8_t id, uint8_t maxTemp) {
    uint8_t prm = maxTemp;
    uint8_t data[7] = {0x55, 0x55, id, 4, SERVO_TEMP_MAX_LIMIT_WRITE, prm};
    data[6] = Servo_CheckSum(id, 4, SERVO_TEMP_MAX_LIMIT_WRITE, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);
}

// ========== 读取类函数 ==========

/**
 * @brief 读取舵机当前位置
 * @param id 舵机ID (1-253)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 5 28 POS_L POS_H CHECKSUM
 */
void Servo_ReadPosition(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_POS_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_POS_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 读取舵机实时电压
 * @param id 舵机ID (1-253)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 5 27 VIN_L VIN_H CHECKSUM (单位mV)
 */
void Servo_ReadVoltage(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_VIN_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_VIN_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 读取舵机实时温度
 * @param id 舵机ID (1-253)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 4 26 TEMP CHECKSUM (单位℃)
 */
void Servo_ReadTemperature(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_TEMP_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_TEMP_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 读取舵机ID
 * @param id 舵机ID (1-253) 或 254(广播查询)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 4 14 ID CHECKSUM
 *       广播查询时所有舵机都会回复,可能造成冲突
 */
void Servo_ReadID(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_ID_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_ID_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 读取角度限位
 * @param id 舵机ID (1-253)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 7 21 MIN_L MIN_H MAX_L MAX_H CHECKSUM
 */
void Servo_ReadAngleLimit(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_ANGLE_LIMIT_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_ANGLE_LIMIT_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

/**
 * @brief 读取当前模式
 * @param id 舵机ID (1-253)
 * @note 舵机会返回数据,需在UART4接收回调中解析
 *       返回格式: 0x55 0x55 ID 7 30 MODE 0 SPEED_L SPEED_H CHECKSUM
 */
void Servo_ReadMode(uint8_t id) {
    uint8_t data[6] = {0x55, 0x55, id, 3, SERVO_MODE_READ};
    data[5] = Servo_CheckSum(id, 3, SERVO_MODE_READ, NULL, 0);

    HAL_UART_Transmit(&huart3, data, 6, 100);
}

// ========== LED控制函数 ==========

/**
 * @brief LED控制
 * @param id 舵机ID (1-253)
 * @param ledState 0=常亮, 1=常灭
 */
void Servo_SetLED(uint8_t id, uint8_t ledState) {
    uint8_t prm = ledState;
    uint8_t data[7] = {0x55, 0x55, id, 4, SERVO_LED_CTRL_WRITE, prm};
    data[6] = Servo_CheckSum(id, 4, SERVO_LED_CTRL_WRITE, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);
}

/**
 * @brief LED报警设置
 * @param id 舵机ID (1-253)
 * @param errorMask 报警项 (可累加)
 *        - 1: 过温报警
 *        - 2: 过压报警
 *        - 4: 堵转报警
 *        例: errorMask=7 表示同时启用三种报警
 */
void Servo_SetLEDError(uint8_t id, uint8_t errorMask) {
    uint8_t prm = errorMask;
    uint8_t data[7] = {0x55, 0x55, id, 4, SERVO_LED_ERROR_WRITE, prm};
    data[6] = Servo_CheckSum(id, 4, SERVO_LED_ERROR_WRITE, &prm, 1);

    HAL_UART_Transmit(&huart3, data, 7, 100);
}