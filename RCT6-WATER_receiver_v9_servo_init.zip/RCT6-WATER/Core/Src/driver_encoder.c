/**
  ******************************************************************************
  * @file    driver_encoder.c
  * @brief   Quadrature Encoder Driver Implementation for STM32F103
  * @author  Ported from original balance car project
  * @date    2024
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "driver_encoder.h"

/* Public Functions ----------------------------------------------------------*/

/**
  * @brief  Read encoder count and reset counter
  * @param  htim: Pointer to TIM handle configured in encoder mode
  * @retval Encoder count since last read (signed short)
  *
  * @details
  * This function reads the encoder counter value and resets it to zero.
  * It should be called periodically at a fixed interval (e.g., 10ms)
  * to measure motor speed.
  *
  * How it works:
  * 1. Read current counter value (accumulated pulses)
  * 2. Cast to signed short to handle overflow correctly
  * 3. Reset counter to 0 for next measurement period
  *
  * The signed short cast handles the case where the encoder counts
  * backward (counter wraps from 0 to 65535), interpreting it correctly
  * as a negative value.
  */
int Driver_Encoder_Read(TIM_HandleTypeDef *htim)
{
    int count;

    // Read counter value (cast to short for signed interpretation)
    count = (short)__HAL_TIM_GetCounter(htim);

    // Reset counter for next reading period
    __HAL_TIM_SetCounter(htim, 0);

    // 注意：
    // 1. 如果使用TI12模式(4倍频)，需要除以4
    // 2. 如果编码器安装在电机轴，需要除以减速比(30)才能得到输出轴转数
    //
    // 当前配置：TI1模式(1倍频) + 编码器在电机轴
    // 如果需要输出轴转数，取消下面这行的注释：
    // return count / 30;  // 30是减速比

    return count;
}

/**
  * @brief  Read left encoder speed
  * @param  None
  * @retval Encoder count (pulses since last read)
  */
int Driver_Encoder_ReadLeft(void)
{
    return Driver_Encoder_Read(&ENCODER_LEFT_TIM);
}

/**
  * @brief  Read right encoder speed
  * @param  None
  * @retval Encoder count (pulses since last read)
  * @note   Sign is inverted to match mechanical orientation
  */
int Driver_Encoder_ReadRight(void)
{
    // Note: Original code inverts right encoder reading
    // Adjust based on your mechanical setup
    return -Driver_Encoder_Read(&ENCODER_RIGHT_TIM);
}

/**
  * @brief  Manually reset encoder counter
  * @param  htim: Pointer to TIM handle
  * @retval None
  */
void Driver_Encoder_Reset(TIM_HandleTypeDef *htim)
{
    __HAL_TIM_SetCounter(htim, 0);
}
