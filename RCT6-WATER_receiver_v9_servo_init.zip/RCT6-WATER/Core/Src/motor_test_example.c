/**
  ******************************************************************************
  * @file    motor_test_example.c
  * @brief   电机驱动测试示例代码
  * @note    这个文件包含各种电机控制的示例,可以复制到main.c中使用
  * @warning 这个文件仅供参考,不要直接编译!请将需要的函数复制到main.c中使用
  ******************************************************************************
  */

/*
 * ============================================================================
 * 重要说明: 这个文件不应该被编译!
 * ============================================================================
 * 这是一个示例代码集合,包含了各种电机控制的使用方法。
 * 请根据需要将相应的函数复制到 main.c 中使用。
 *
 * 如果你看到编译错误,请在Keil工程中将此文件从编译列表中移除:
 * 1. 在Keil左侧项目树中找到这个文件
 * 2. 右键 -> Options for File 'motor_test_example.c'
 * 3. 勾选 "Exclude from Build"
 * ============================================================================
 */

#if 0  // 防止编译,如需使用请将代码复制到main.c

#include "driver_motor.h"
#include "driver_encoder.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>

/* ============================================================================
 * 示例1: 基本电机控制
 * ============================================================================ */
void Example1_BasicMotorControl(void)
{
    // 两个电机都正转,速度3000
    Driver_Motor_SetSpeed(3000, 3000);
    HAL_Delay(2000);  // 运行2秒

    // 停止
    Driver_Motor_Stop();
    HAL_Delay(1000);

    // 两个电机都反转,速度-3000
    Driver_Motor_SetSpeed(-3000, -3000);
    HAL_Delay(2000);

    // 停止
    Driver_Motor_Stop();
}

/* ============================================================================
 * 示例2: 转向控制
 * ============================================================================ */
void Example2_TurnControl(void)
{
    // 左转: 左轮慢速,右轮快速
    Driver_Motor_SetSpeed(2000, 4000);
    HAL_Delay(1000);

    // 右转: 左轮快速,右轮慢速
    Driver_Motor_SetSpeed(4000, 2000);
    HAL_Delay(1000);

    // 原地左转: 左轮反转,右轮正转
    Driver_Motor_SetSpeed(-3000, 3000);
    HAL_Delay(1000);

    // 原地右转: 左轮正转,右轮反转
    Driver_Motor_SetSpeed(3000, -3000);
    HAL_Delay(1000);

    // 停止
    Driver_Motor_Stop();
}

/* ============================================================================
 * 示例3: 速度限幅
 * ============================================================================ */
void Example3_SpeedLimit(void)
{
    int motor1 = 9000;   // 超过最大值7200
    int motor2 = -9000;  // 低于最小值-7200

    // 自动限幅到±7200
    Driver_Motor_Limit(&motor1, &motor2);

    // 现在 motor1 = 7200, motor2 = -7200
    Driver_Motor_SetSpeed(motor1, motor2);
    HAL_Delay(2000);

    Driver_Motor_Stop();
}

/* ============================================================================
 * 示例4: 编码器读取(在定时器中断中调用)
 * ============================================================================ */
void Example4_EncoderRead(void)
{
    // 这个函数应该在定时器中断中每10-50ms调用一次
    int encoder_left = Driver_Encoder_ReadLeft();
    int encoder_right = Driver_Encoder_ReadRight();

    // 打印编码器值
    char msg[100];
    sprintf(msg, "Encoder L:%d R:%d\r\n", encoder_left, encoder_right);
    Usart2_SendString((uint8_t*)msg);

    // 根据编码器值计算速度(假设10ms调用一次)
    // 速度(转/分) = (编码器脉冲数 * 60) / (10ms * 编码器线数 * 4倍频)
    // 例如:编码器线数=11, 4倍频后每转44个脉冲
    // speed_rpm = (encoder_count * 60 * 1000) / (10 * 11 * 4)
}

/* ============================================================================
 * 示例5: 速度闭环控制(简化版PID)
 * ============================================================================ */
typedef struct {
    int target_speed;      // 目标速度(编码器脉冲/10ms)
    int current_speed;     // 当前速度
    int error;             // 误差
    int last_error;        // 上次误差
    int pwm_output;        // PWM输出
    float kp;              // 比例系数
    float ki;              // 积分系数
    float kd;              // 微分系数
    int integral;          // 积分累计
} PID_Controller;

PID_Controller motor1_pid = {0};
PID_Controller motor2_pid = {0};

void PID_Init(PID_Controller *pid, float kp, float ki, float kd)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->integral = 0;
    pid->last_error = 0;
}

int PID_Compute(PID_Controller *pid, int target, int current)
{
    // 计算误差
    pid->error = target - current;

    // 积分项
    pid->integral += pid->error;

    // 积分限幅,防止积分饱和
    if(pid->integral > 5000) pid->integral = 5000;
    if(pid->integral < -5000) pid->integral = -5000;

    // PID计算
    int p_term = (int)(pid->kp * pid->error);
    int i_term = (int)(pid->ki * pid->integral);
    int d_term = (int)(pid->kd * (pid->error - pid->last_error));

    // 更新上次误差
    pid->last_error = pid->error;

    // 计算输出
    pid->pwm_output = p_term + i_term + d_term;

    // 输出限幅
    if(pid->pwm_output > 7200) pid->pwm_output = 7200;
    if(pid->pwm_output < -7200) pid->pwm_output = -7200;

    return pid->pwm_output;
}

void Example5_SpeedControl(void)
{
    // 初始化PID(这个只需要调用一次)
    PID_Init(&motor1_pid, 50.0f, 0.5f, 0.1f);
    PID_Init(&motor2_pid, 50.0f, 0.5f, 0.1f);

    // 在定时器中断中(每10ms)调用:
    // 读取编码器
    int encoder1 = Driver_Encoder_ReadLeft();
    int encoder2 = Driver_Encoder_ReadRight();

    // 设置目标速度(假设目标是每10ms走20个脉冲)
    int target_speed = 20;

    // PID计算
    int pwm1 = PID_Compute(&motor1_pid, target_speed, encoder1);
    int pwm2 = PID_Compute(&motor2_pid, target_speed, encoder2);

    // 输出到电机
    Driver_Motor_SetSpeed(pwm1, pwm2);
}

/* ============================================================================
 * 示例6: 串口控制电机
 * ============================================================================ */
void Example6_UARTControl(void)
{
    // 在main循环中检查串口数据
    if (RecieveFlag2 == 1)  // 假设使用USART2
    {
        RecieveFlag2 = 0;

        // 简单的命令解析
        // 格式: "M1500,2000" 表示电机1速度1500,电机2速度2000
        if(RxBuffer2[0] == 'M')
        {
            int speed1, speed2;
            if(sscanf((char*)&RxBuffer2[1], "%d,%d", &speed1, &speed2) == 2)
            {
                // 限速
                Driver_Motor_Limit(&speed1, &speed2);

                // 设置速度
                Driver_Motor_SetSpeed(speed1, speed2);

                // 回复确认
                char msg[50];
                sprintf(msg, "OK: Motor1=%d, Motor2=%d\r\n", speed1, speed2);
                Usart2_SendString((uint8_t*)msg);
            }
        }
        // 停止命令
        else if(RxBuffer2[0] == 'S')
        {
            Driver_Motor_Stop();
            Usart2_SendString((uint8_t*)"Motor Stopped\r\n");
        }
    }
}

/* ============================================================================
 * 如何在main.c中使用这些示例
 * ============================================================================
 *
 * 1. 在main函数的初始化部分(USER CODE BEGIN 2):
 *    // 启动PWM和编码器(已添加)
 *    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
 *    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
 *    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
 *    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
 *    Driver_Motor_Stop();
 *
 * 2. 在主循环中(USER CODE BEGIN 3):
 *    // 选择一个示例运行
 *    Example1_BasicMotorControl();  // 基本控制测试
 *    // 或
 *    Example6_UARTControl();         // 串口控制
 *
 * 3. 如果使用PID控制,需要配置一个定时器中断(10ms):
 *    void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
 *    {
 *        if(htim->Instance == TIM3)  // 假设用TIM3作为10ms定时器
 *        {
 *            Example5_SpeedControl();
 *        }
 *    }
 *
 * ============================================================================
 */

#endif  // 结束 #if 0

