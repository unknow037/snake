/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "driver_motor.h"
#include "driver_encoder.h"
#include "servo.h"
#include "LORA.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// ==================== LORA 设备配置 ====================
// 修改这个宏来选择设备类型: 0=设备A(发送机), 1=设备B(接收机)
#define DEVICE_TYPE 0  // 0: 设备A,  1: 设备B

// 简化测试：两个设备使用相同的地址和信道（透传模式）
#define DEVICE_A_ADDR_H     0x00
#define DEVICE_A_ADDR_L     0x01
#define DEVICE_A_CHANNEL    5

// 设备B使用相同配置
#define DEVICE_B_ADDR_H     0x00
#define DEVICE_B_ADDR_L     0x01
#define DEVICE_B_CHANNEL    5

// 遥控器ADC控制参数
#define RC_ADC_MIN          0
#define RC_ADC_MAX          4095
#define RC_ADC_DEFAULT_MID  2048
#define RC_DEADZONE         120
#define RC_MOTOR_MAX        3600
#define RC_SERVO_CENTER     500
#define RC_SERVO_RANGE      300
#define RC_SERVO_MIN        200
#define RC_SERVO_MAX        800

// 根据DEVICE_TYPE选择当前设备配置
#if DEVICE_TYPE == 0
    #define MY_ADDR_H       DEVICE_A_ADDR_H
    #define MY_ADDR_L       DEVICE_A_ADDR_L
    #define MY_CHANNEL      DEVICE_A_CHANNEL
    #define TARGET_ADDR_H   DEVICE_B_ADDR_H
    #define TARGET_ADDR_L   DEVICE_B_ADDR_L
    #define TARGET_CHANNEL  DEVICE_B_CHANNEL
    #define DEVICE_NAME     "Device A (Transmitter)"
#else
    #define MY_ADDR_H       DEVICE_B_ADDR_H
    #define MY_ADDR_L       DEVICE_B_ADDR_L
    #define MY_CHANNEL      DEVICE_B_CHANNEL
    #define TARGET_ADDR_H   DEVICE_A_ADDR_H
    #define TARGET_ADDR_L   DEVICE_A_ADDR_L
    #define TARGET_CHANNEL  DEVICE_A_CHANNEL
    #define DEVICE_NAME     "Device B (Receiver)"
#endif

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
// 测试用的静态变量
static uint32_t test_counter = 0;
static int encoder_left = 0;
static int encoder_right = 0;

// 按键控制变量
static uint8_t motor_running = 0;        // 电机运行状态: 0=停止, 1=运行

// 舵机测试变量
static uint8_t servo_mode = 0;           // 舵机模式: 0=电机模式, 1=舵机位置模式

// LORA 相关变量
static uint32_t lora_send_counter = 0;   // LORA发送计数器
static uint16_t lora_packet_count = 0;   // LORA数据包计数
static uint8_t motor_servo_running = 0;  // 电机和舵机运行状态: 0=停止, 1=运行

// 遥控器接收数据
static uint16_t rc_x1 = RC_ADC_DEFAULT_MID;
static uint16_t rc_y1 = RC_ADC_DEFAULT_MID;
static uint16_t rc_x2 = RC_ADC_DEFAULT_MID;
static uint16_t rc_y2 = RC_ADC_DEFAULT_MID;
static uint16_t rc_x1_mid = RC_ADC_DEFAULT_MID;
static uint16_t rc_y1_mid = RC_ADC_DEFAULT_MID;
static uint16_t rc_x2_mid = RC_ADC_DEFAULT_MID;
static uint16_t rc_y2_mid = RC_ADC_DEFAULT_MID;
static uint8_t rc_center_ready = 0;
static uint32_t rc_last_rx_tick = 0;
static uint32_t rc_last_servo_tick = 0;
static uint16_t rc_last_servo1 = RC_SERVO_CENTER;
static uint16_t rc_last_servo2 = RC_SERVO_CENTER;
static char rc_debug_buf[160];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/**
  * @brief  按键扫描函数(简化版,带消抖)
  * @retval 1=检测到按键按下事件, 0=无按键事件
  */
uint8_t Button_Scan(void)
{
    static uint8_t button_pressed = 0;  // 按键按下标志
    uint8_t button_event = 0;

    // 读取当前按键状态(上拉输入,按下为低电平0)
    uint8_t button_current = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8);

    // 按键按下(低电平)且之前未按下
    if (button_current == 0 && button_pressed == 0)
    {
        HAL_Delay(20);  // 简单消抖延时
        // 再次确认按键仍然按下
        if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8) == 0)
        {
            button_pressed = 1;  // 标记按键已按下
            button_event = 1;    // 触发按键事件
        }
    }
    // 按键释放(高电平)
    else if (button_current == 1)
    {
        button_pressed = 0;  // 清除按键按下标志
    }

    return button_event;
}

/**
  * @brief  LORA初始化并配置设备地址和信道（透传模式测试）
  * @retval None
  */
void LORA_Device_Init(void)
{
    // 步骤1: 初始化LORA模块（复位、设置为透传模式）
    LORA_Init();
    HAL_Delay(100);
    Uart4_SendString((uint8_t*)"[LORA] Step 1: Module initialized\r\n");

    // 步骤2: 配置本机地址和信道
    uint16_t my_addr = (MY_ADDR_H << 8) | MY_ADDR_L;
    if (LORA_Set_Address_And_Channel(my_addr, MY_CHANNEL))
    {
        Uart4_SendString((uint8_t*)"[LORA] Step 2: Address & Channel configured\r\n");
    }
    else
    {
        Uart4_SendString((uint8_t*)"[LORA] ERROR: Failed to configure address!\r\n");
        return;  // 配置失败，直接返回
    }

    HAL_Delay(100);

    // 透明传输模式：遥控器直接透传ADC字符串，接收机从USART2接收原始字符串。
    if (LORA_Disable_Fixed_Transmission())
    {
        Uart4_SendString((uint8_t*)"[LORA] Transparent mode enabled\r\n");
    }
    else
    {
        Uart4_SendString((uint8_t*)"[LORA] WARNING: Transparent mode set failed\r\n");
    }

    // 步骤3: 验证配置：读取地址和信道
    uint8_t read_buffer[10];
    if (LORA_ReadReg(0x00, 3, read_buffer))
    {
        Uart4_SendString((uint8_t*)"[LORA] Verify - Config read OK\r\n");
    }
    else
    {
        Uart4_SendString((uint8_t*)"[LORA] WARNING: Cannot read address/channel!\r\n");
    }

    Uart4_SendString((uint8_t*)"[LORA] Ready for transparent transmission!\r\n");
}

/**
  * @brief  设备B - 按键触发发送控制命令（透传模式）
  * @retval None
  */
void Device_B_Send_Command(void)
{
    // 发送控制命令：AA BB CC
    uint8_t tx_data[3] = {0xAA, 0xBB, 0xCC};

    // 透传模式下直接通过UART2发送数据（使用DMA）
    USART2_DMA_Transmit(tx_data, 3);

    lora_packet_count++;
    Uart4_SendString((uint8_t*)"[TX->A] Sent CMD #");

    // 显示发送次数
    if(lora_packet_count < 10) {
        uint8_t num_str[2] = {'0' + lora_packet_count, 0};
        Uart4_SendString(num_str);
    } else {
        Uart4_SendString((uint8_t*)"9+");
    }
    Uart4_SendString((uint8_t*)"\r\n");

    // 等待一下让DMA完成
    HAL_Delay(50);
}

static int RC_FindValue(const char *buf, const char *key, uint16_t *value)
{
    const char *p = strstr(buf, key);
    long temp;

    if (p == NULL)
    {
        return 0;
    }

    p += strlen(key);
    temp = strtol(p, NULL, 10);
    if (temp < RC_ADC_MIN) temp = RC_ADC_MIN;
    if (temp > RC_ADC_MAX) temp = RC_ADC_MAX;

    *value = (uint16_t)temp;
    return 1;
}

static int RC_ParsePacket(uint8_t *data, uint16_t len)
{
    char packet[220];
    char *start;
    char *first_x2;
    char *second_x2;
    uint16_t new_x1 = rc_x1;
    uint16_t new_y1 = rc_y1;
    uint16_t new_x2 = rc_x2;
    uint16_t new_y2 = rc_y2;

    if (len == 0)
    {
        return 0;
    }

    if (len >= sizeof(packet))
    {
        len = sizeof(packet) - 1;
    }

    memcpy(packet, data, len);
    packet[len] = '\0';

    // 兼容定点传输可能带来的前导字节，直接从 X1: 开始解析
    start = strstr(packet, "X1:");
    if (start == NULL)
    {
        return 0;
    }

    if (!RC_FindValue(start, "X1:", &new_x1)) return 0;
    if (!RC_FindValue(start, "Y1:", &new_y1)) return 0;
    if (!RC_FindValue(start, "X2:", &new_x2)) return 0;

    // 优先解析正确的 Y2；如果遥控器仍然发送第二个 X2，则把第二个 X2 当成 Y2
    if (!RC_FindValue(start, "Y2:", &new_y2))
    {
        first_x2 = strstr(start, "X2:");
        second_x2 = (first_x2 != NULL) ? strstr(first_x2 + 3, "X2:") : NULL;
        if (second_x2 != NULL)
        {
            long temp = strtol(second_x2 + 3, NULL, 10);
            if (temp < RC_ADC_MIN) temp = RC_ADC_MIN;
            if (temp > RC_ADC_MAX) temp = RC_ADC_MAX;
            new_y2 = (uint16_t)temp;
        }
    }

    rc_x1 = new_x1;
    rc_y1 = new_y1;
    rc_x2 = new_x2;
    rc_y2 = new_y2;

    // 第一次收到有效数据时自动标定摇杆中位，解决只能单向转的问题
    if (rc_center_ready == 0)
    {
        rc_x1_mid = rc_x1;
        rc_y1_mid = rc_y1;
        rc_x2_mid = rc_x2;
        rc_y2_mid = rc_y2;
        rc_center_ready = 1;
        Uart4_SendString((uint8_t*)"[RC] Center calibrated\r\n");
    }

    return 1;
}

static int RC_MapAroundCenter(uint16_t value, uint16_t center, int out_max)
{
    int diff = (int)value - (int)center;
    int range;
    int out;

    if (diff > -RC_DEADZONE && diff < RC_DEADZONE)
    {
        return 0;
    }

    if (diff > 0)
    {
        range = RC_ADC_MAX - center - RC_DEADZONE;
        if (range < 1) range = 1;
        out = (diff - RC_DEADZONE) * out_max / range;
    }
    else
    {
        range = center - RC_ADC_MIN - RC_DEADZONE;
        if (range < 1) range = 1;
        out = (diff + RC_DEADZONE) * out_max / range;
    }

    if (out > out_max) out = out_max;
    if (out < -out_max) out = -out_max;
    return out;
}

static uint16_t RC_MapServoAroundCenter(uint16_t value, uint16_t center)
{
    int offset = RC_MapAroundCenter(value, center, RC_SERVO_RANGE);
    int angle = RC_SERVO_CENTER + offset;

    if (angle < RC_SERVO_MIN) angle = RC_SERVO_MIN;
    if (angle > RC_SERVO_MAX) angle = RC_SERVO_MAX;

    return (uint16_t)angle;
}

static void RC_UpdateMotorAndServo(void)
{
    int forward;
    int turn;
    int left;
    int right;
    uint16_t servo1;
    uint16_t servo2;

    // ADC1：Y1控制前进/后退，X1控制转向
    forward = RC_MapAroundCenter(rc_y1, rc_y1_mid, RC_MOTOR_MAX);
    turn = RC_MapAroundCenter(rc_x1, rc_x1_mid, RC_MOTOR_MAX / 2);

    left = forward + turn;
    right = forward - turn;

    if (left > RC_MOTOR_MAX) left = RC_MOTOR_MAX;
    if (left < -RC_MOTOR_MAX) left = -RC_MOTOR_MAX;
    if (right > RC_MOTOR_MAX) right = RC_MOTOR_MAX;
    if (right < -RC_MOTOR_MAX) right = -RC_MOTOR_MAX;

    Driver_Motor_SetSpeed(left, right);

    // ADC2：X2控制舵机1，Y2控制舵机2；限制在 200~800，避免一直打到最大角
    servo1 = RC_MapServoAroundCenter(rc_x2, rc_x2_mid);
    servo2 = RC_MapServoAroundCenter(rc_y2, rc_y2_mid);

    // 舵机命令限频，并且角度变化较小时不重复发送
    if ((HAL_GetTick() - rc_last_servo_tick) >= 50)
    {
        if (servo1 > rc_last_servo1 + 5 || servo1 + 5 < rc_last_servo1)
        {
            Servo_Move(1, servo1, 80);
            rc_last_servo1 = servo1;
        }

        if (servo2 > rc_last_servo2 + 5 || servo2 + 5 < rc_last_servo2)
        {
            Servo_Move(2, servo2, 80);
            rc_last_servo2 = servo2;
        }

        rc_last_servo_tick = HAL_GetTick();
    }
}

/**
  * @brief  设备A - 处理接收到的控制命令
  * @retval None
  */
void Device_A_Process_Command(void)
{
    // 检查USART2是否收到数据
    if (RecieveFlag2 == 1)
    {
        RecieveFlag2 = 0;  // 清除标志
        rc_last_rx_tick = HAL_GetTick();

        if (RC_ParsePacket(RxBuffer2, RxDataLen2))
        {
            lora_packet_count++;
            RC_UpdateMotorAndServo();

            if (lora_packet_count <= 5 || (lora_packet_count % 10) == 0)
            {
                snprintf(rc_debug_buf, sizeof(rc_debug_buf),
                         "[RC] X1:%u Y1:%u X2:%u Y2:%u C:%u,%u,%u,%u\r\n",
                         rc_x1, rc_y1, rc_x2, rc_y2,
                         rc_x1_mid, rc_y1_mid, rc_x2_mid, rc_y2_mid);
                Uart4_SendString((uint8_t*)rc_debug_buf);
            }
        }
        else
        {
            Uart4_SendString((uint8_t*)"[RC] Invalid packet\r\n");
        }
    }

    // 超过 1 秒没有新数据，立即停电机；舵机保持当前位置
    if (rc_last_rx_tick != 0 && (HAL_GetTick() - rc_last_rx_tick) > 1000)
    {
        Driver_Motor_Stop();
    }
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* PC13上电自检：能看到快速闪烁说明GPIO控制正常 */
  for (uint8_t i = 0; i < 6; i++)
  {
      HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
      HAL_Delay(150);
  }
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
  MX_DMA_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  HAL_Delay(500);
  // ==================== 电机和舵机初始化 ====================
#if DEVICE_TYPE == 0
  // 设备A需要启动PWM（用于电机和舵机）
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);  // 电机2 PWM
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);  // 电机1 PWM

  // 启动编码器
  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);  // 左轮编码器
  HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);  // 右轮编码器

  // 停止电机(安全初始化)
  Driver_Motor_Stop();
  motor_servo_running = 0;  // 初始状态为停止

  // 舵机初始化：确保舵机在上电时回到中间位置
  HAL_Delay(200);  // 等待舵机上电稳定（总线舵机需要较长时间）

  // 1. 先使能力矩
  Servo_SetTorque(1, 1);
  HAL_Delay(50);
  Servo_SetTorque(2, 1);
  HAL_Delay(50);

  // 2. 发送中间位置指令（角度500 = 机械中位，500ms内到达）
  Servo_Move(1, RC_SERVO_CENTER, 500);
  HAL_Delay(50);
  Servo_Move(2, RC_SERVO_CENTER, 500);

  // 3. 等待舵机运动到位（至少等500ms）
  HAL_Delay(600);

  // 4. 再发一次确认位置，防止上电时第一次指令丢失
  Servo_Move(1, RC_SERVO_CENTER, 200);
  HAL_Delay(50);
  Servo_Move(2, RC_SERVO_CENTER, 200);
  HAL_Delay(300);

  Uart4_SendString((uint8_t*)"[INIT] Motor and Servo initialized (servos centered)\r\n");
#endif

  // ==================== LORA 初始化 ====================
  // 通过串口4发送启动信息
  Uart4_SendString((uint8_t*)"\r\n");
  Uart4_SendString((uint8_t*)"====================================\r\n");
  Uart4_SendString((uint8_t*)"    LORA Fixed Transmission Test    \r\n");
  Uart4_SendString((uint8_t*)"====================================\r\n");
  Uart4_SendString((uint8_t*)"Device Type: ");
  Uart4_SendString((uint8_t*)DEVICE_NAME);
  Uart4_SendString((uint8_t*)"\r\n");
  Uart4_SendString((uint8_t*)"====================================\r\n");

  // 初始化LORA模块
  Uart4_SendString((uint8_t*)"[INIT] Starting LORA initialization...\r\n");
  LORA_Device_Init();
  Uart4_SendString((uint8_t*)"[INIT] LORA initialization complete!\r\n");

#if DEVICE_TYPE == 0
  Uart4_SendString((uint8_t*)"\r\n[Receiver] Waiting for ADC data from remote controller...\r\n");
  Uart4_SendString((uint8_t*)"[Receiver] Keep joysticks centered before first packet for calibration\r\n");
#else
  Uart4_SendString((uint8_t*)"\r\n[Device B] Press PC8 button to send command to Device A\r\n");
#endif

  Uart4_SendString((uint8_t*)"====================================\r\n\r\n");

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    // ==================== LORA 通信处理 ====================
#if DEVICE_TYPE == 0
    // 设备A (接收机): 接收设备B的控制命令并执行
    Device_A_Process_Command();
	
#else
    // 设备B (发送机): 按键触发发送控制命令
    if (Button_Scan())
    {
        Device_B_Send_Command();
    }
#endif



    // ==================== 非LORA功能暂时注释 ====================
    /*
    // 每隔5000ms读取一次编码器
    if (HAL_GetTick() - test_counter >= 5000)
    {
        test_counter = HAL_GetTick();

        // 读取编码器值
        encoder_left = Driver_Encoder_ReadLeft();
        encoder_right = Driver_Encoder_ReadRight();

        // 通过串口4输出编码器值
        Uart4_SendString((uint8_t*)"[Encoder] Read\r\n");
    }

    // 检查USART1是否收到数据
    if (RecieveFlag == 1)
    {
        RecieveFlag = 0;  // 清除标志

        // 回显接收到的数据
        Usart1_SendString((uint8_t*)"USART1: ");
        Usart1_SendString(RxBuffer);
        Usart1_SendString((uint8_t*)"\r\n");
    }

    // 检查USART3是否收到数据
    if (RecieveFlag3 == 1)
    {
        RecieveFlag3 = 0;  // 清除标志

        // 回显接收到的数据
        Usart3_SendString((uint8_t*)"USART3: ");
        Usart3_SendString(RxBuffer3);
        Usart3_SendString((uint8_t*)"\r\n");
    }

    // 检查UART4是否收到数据
    if (RecieveFlag4 == 1)
    {
        RecieveFlag4 = 0;  // 清除标志

        // 回显接收到的数据
        Uart4_SendString((uint8_t*)"UART4: ");
        Uart4_SendString(RxBuffer4);
        Uart4_SendString((uint8_t*)"\r\n");
    }

    // 检查UART5是否收到数据
    if (RecieveFlag5 == 1)
    {
        RecieveFlag5 = 0;  // 清除标志

        // 回显接收到的数据
        Uart5_SendString((uint8_t*)"UART5: ");
        Uart5_SendString(RxBuffer5);
        Uart5_SendString((uint8_t*)"\r\n");
    }
    */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
