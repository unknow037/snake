/**
  ******************************************************************************
  * @file    driver_motor.c
  * @brief   DC Motor Driver Implementation for STM32F103
  * @author  Ported from original balance car project
  * @date    2024
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "driver_motor.h"

/* Private Functions ---------------------------------------------------------*/

/**
  * @brief  Calculate absolute value
  * @param  value: Input integer
  * @retval Absolute value
  */
int Driver_Motor_Abs(int value)
{
    if(value > 0)
        return value;
    else
        return -value;
}

/* Public Functions ----------------------------------------------------------*/

/**
  * @brief  Set motor speed and direction for both motors
  * @param  motor1_speed: Speed for motor 1 (-7200 to +7200)
  * @param  motor2_speed: Speed for motor 2 (-7200 to +7200)
  * @retval None
  *
  * @details
  * This function controls two DC motors:
  * - Motor 1 (typically left wheel)
  * - Motor 2 (typically right wheel)
  *
  * Speed value interpretation:
  * - Positive value: Motor rotates forward
  * - Negative value: Motor rotates backward
  * - Zero: Motor stops
  *
  * Direction control:
  * - Two GPIO pins per motor control direction via H-bridge
  * - PWM controls speed magnitude
  */
void Driver_Motor_SetSpeed(int motor1_speed, int motor2_speed)
{
    // Motor 1 Direction Control
    if(motor1_speed > 0)
    {
        // Forward direction
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_FWD, GPIO_PIN_SET);
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_REV, GPIO_PIN_RESET);
    }
    else if(motor1_speed < 0)
    {
        // Reverse direction
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_FWD, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_REV, GPIO_PIN_SET);
    }
    else
    {
        // Stop direction
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_FWD, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(MOTOR1_DIR_GPIO_PORT, MOTOR1_DIR_PIN_REV, GPIO_PIN_RESET);
    }

    // Motor 1 PWM Speed (absolute value)
    __HAL_TIM_SetCompare(&MOTOR_TIM_HANDLE, MOTOR1_TIM_CHANNEL, Driver_Motor_Abs(motor1_speed));

    // Motor 2 Direction Control
    if(motor2_speed > 0)
    {
        // Forward direction
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_FWD, GPIO_PIN_SET);
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_REV, GPIO_PIN_RESET);
    }
    else if(motor2_speed < 0)
    {
        // Reverse direction
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_FWD, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_REV, GPIO_PIN_SET);
    }
    else
    {
        // Stop direction
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_FWD, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(MOTOR2_DIR_GPIO_PORT, MOTOR2_DIR_PIN_REV, GPIO_PIN_RESET);
    }

    // Motor 2 PWM Speed (absolute value)
    __HAL_TIM_SetCompare(&MOTOR_TIM_HANDLE, MOTOR2_TIM_CHANNEL, Driver_Motor_Abs(motor2_speed));
}

/**
  * @brief  Limit motor speed values to safe range
  * @param  motor1_speed: Pointer to motor 1 speed variable
  * @param  motor2_speed: Pointer to motor 2 speed variable
  * @retval None
  */
void Driver_Motor_Limit(int *motor1_speed, int *motor2_speed)
{
    // Limit Motor 1
    if(*motor1_speed > MOTOR_PWM_MAX)
        *motor1_speed = MOTOR_PWM_MAX;
    if(*motor1_speed < MOTOR_PWM_MIN)
        *motor1_speed = MOTOR_PWM_MIN;

    // Limit Motor 2
    if(*motor2_speed > MOTOR_PWM_MAX)
        *motor2_speed = MOTOR_PWM_MAX;
    if(*motor2_speed < MOTOR_PWM_MIN)
        *motor2_speed = MOTOR_PWM_MIN;
}

/**
  * @brief  Emergency stop both motors
  * @param  None
  * @retval None
  */
void Driver_Motor_Stop(void)
{
    Driver_Motor_SetSpeed(0, 0);
}
